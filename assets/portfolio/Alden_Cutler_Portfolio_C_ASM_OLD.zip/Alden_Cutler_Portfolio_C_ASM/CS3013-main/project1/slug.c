#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

void endProcess();

// Helper function to get seed value as integer from file depending on command line arg
int getSeed(char num[]) {

	FILE *fp;
	char mainFile[] = "seed_slug_";
	char endFile[] = ".txt";
	strcat(mainFile, num);
	strcat(mainFile, endFile);
	fp = fopen(mainFile, "r");
	char str[100];
	int seed;

	if (fp == NULL) {
		printf("Could not open file %s\n", mainFile);
		return 1;
	}

	while (fgets(str, 100, fp) != NULL) {
		seed = atoi(str);
	}

	return seed;
}


// calculates delay/exit code, delays, then runs chosen command
void endProcess()
{	

    	// choose random numbers for run time and coin flip
    	int ranTime = rand() % 5 + 2;
    	int coinFlip = rand() % 2;
    	printf("Delay time is %d seconds. Coin flip: %d\n", ranTime, coinFlip);
    	printf("I'll get the job done. Eventually...\n");
	
	// sleep for specified amount of time
	sleep(ranTime);

	// run specified command based on coin flip value
	int status_code;
    	if (coinFlip == 0)
    	{
        	printf("Break time is over! I am running the 'last -i -x' command.\n");
        	status_code = execlp("last", "last", "-i", "-x", (char *)NULL);
    	}
    	else
    	{
        	printf("Break time is over! I am running the 'id --group' command.\n");
        	status_code = execlp("id", "id", "--group", (char *)NULL);
    	}

    	if (status_code == -1)
    	{
        	perror("Error executing command");
        	exit(EXIT_FAILURE);
    	}
}


int main(int argc, char *argv[])
{
	// if no command line argument was passed in, exit
    	if (argc != 2)
    	{
       		fprintf(stderr, "Usage: %s <seed_number>\n", argv[0]);
        	exit(EXIT_FAILURE);
    	}

	// convert to int
    	int seed = atoi(argv[1]);

	// read in seed value for srand()
    	if (seed >= 1 && seed <= 4)
    	{
        	srand(getSeed(argv[1]));
        	printf("\nRead seed value (converted to integer): %d\n", getSeed(argv[1]));
        	endProcess();
    	}
	// if seed wasn't between 1 and 4 (inclusive), not a valid seed
    	else
    	{
        	printf("\nNot a valid number\n");
    	}
    	return 0;
}

