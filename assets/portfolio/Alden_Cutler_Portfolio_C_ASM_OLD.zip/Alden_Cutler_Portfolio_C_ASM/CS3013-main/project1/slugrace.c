#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#define NUM_SLUGS 4
#define UPDATE_FREQ 330000	// 330000 microseconds = 330 milliseconds = 0.33 seconds

int main () {

	char* param_nums[4] = {"1", "2", "3", "4"};		// array of strings to pass to execvp
	int* child_pids = calloc(4, sizeof(int));		// array of child pids
	pid_t rc;						// return code of fork()
	int num_racing = 0;					// number of children still racing	

	// spawn 4 children
	for (int i = 0; i < NUM_SLUGS; i++) {
		rc = fork();

		if (rc < 0) {
			// fork failed
			printf("fork failed\n");
			exit(1);
		} else if (rc == 0) {
			// new child process
			printf("	[Child, PID: %d]: Executing './slug %d' command...\n", getpid(), i+1);
			char* arg_list[] = {"./slug.exe", param_nums[i], NULL};
			execvp("./slug.exe", arg_list);
		} 
		// parent process
		else {
			// increment number of children racing
			num_racing++;

			// store child pid in array
			child_pids[i] = rc;

			// print out child pid
			printf("[Parent]: I forked off child %d\n", rc);
			//printf("	[Child, PID: %d]: Executing './slug %d' command...\n", rc, i+1);	
		}
	}
	
	int status;
	struct timespec start, end, current, last;
	clock_gettime(CLOCK_REALTIME, &last);
	clock_gettime(CLOCK_REALTIME, &start);
	

	// while there are still children racing
	while (num_racing > 0) {
	//	usleep(UPDATE_FREQ);
		// waits for any child to finish		
		int result = waitpid(-1, &status, WNOHANG);
		
		// if a child has finished	
		if (result > 0) {
			// check which child finished
			for (int i = 0; i < NUM_SLUGS; i++) {
				if (result == child_pids[i]) {
					clock_gettime(CLOCK_REALTIME, &end);
					printf("Child %d has crossed the finish line! It took %f seconds\n", child_pids[i], (end.tv_sec - start.tv_sec) + 1.0e-9 * (end.tv_nsec - start.tv_nsec));
					child_pids[i] = 0;
					num_racing--;
				}
			}
		} else {

			// check if it's been 0.33 seconds
			clock_gettime(CLOCK_REALTIME, &current);
			if ((current.tv_sec - last.tv_sec) + 1.0e-9 * (current.tv_nsec - last.tv_nsec) >= 0.33) {

				// print out all the racing slugs
				printf("The race is ongoing. The following children are still racing: ");
				for (int i = 0; i < NUM_SLUGS; i++) {
					if (child_pids[i] != 0) {
						printf("%d ", child_pids[i]);
					}
				}
				printf("\n");
			
			
				// reset last time
				clock_gettime(CLOCK_REALTIME, &last);	
			}
		
			// usleep(UPDATE_FREQ);	// this usleep blocks the next check from starting, which I think is why our times were 0.33 seconds off
		}
		// sleep for 0.33 seconds
	
	}
	
	printf("The race is over! It took %f seconds!\n", (end.tv_sec - start.tv_sec) + 1.0e-9 * (end.tv_nsec - start.tv_nsec));

	exit(EXIT_SUCCESS);
}
