This is the work of Alden Cutler and Nia Junod.

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

To Compile:
The Makefile is set up so that if you run 'make' or 'make all', it will compile every executable. Similarly, 'make clean' removes every executable.
If you would like to compile a single C file, use 'make filename'. For example, 'make prolific' will compile prolific.c into prolific.exe.

To Run:
Running each program can be done by typing './filename.exe' after compiling as shown above. For example, after using 'make prolific', enter './prolific.exe' to run the program.

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Scenario 1: prolific.c
The program reads the random seed value from seed.txt and uses it to seed the srand() function. It then (pseudo)randomly chooses the number of children it will create. 
Then, for each child, another random number is created and stored in an array. The child will use this array value to determine how long it will sleep and what status code it will exit with.

Scenario 2: generation.c
The program reads in the random seed value from seed.txt, uses it seed the srand() function, then chooses a (pseudo)random number representing the lifespan.
Then, while the lifespan is greater than 0, it recursively forks to create a child that decrements the lifespan. This continues until the lifespan is 0.

Scenario 3: explorer.c
The program randomly chooses 5 different locations in the file system to visit and run the 'ls -tr' command. For each location chosen, the parent
forks a child to run the command using execvp(), then waits until the child exits before moving onto the next location.

Scenario 4: slug.c
The program takes a command line argument (1, 2, 3, or 4), then based on this value, reads in a unique seed value to seed the srand() function. 
The program then generates two random numbers: the first is the number of seconds the process will wait before continuing, and the second is a coin flip that decides whether the program will run 'id --group' or 'last -i -x'.
It waits the specified number of seconds, runs the specified command, then exits. 

Scenario 5: slugrace.c
The program loops 4 times, each time forking a new child that will execvp() the slug.c program from scenario 4 with a different command line argument. The parent then enters a loop,
checking to see if any child has finished, and if not, printing out the current racing slugs then waiting 0.33 seconds, continuing until all children have finished.

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Program Output:
The output of each program was recorded with the Linux script. We compiled the programs, ran each as described, and then discontinued the script session. 
We processed the resulting output file to remove binary characters and created solution_output.txt.

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Things to Note:

We tested our programs mainly by comparing our output to the sample output at the bottom of the assignment pdf. We also spent some time analyzing the code and comparing what was actually output
to what we would expect the output to be.

We had some issues with timing in scenario 5, where, for some reason, every slug would take almost exactly 0.3 seconds longer than anticipated to finish. 
All the other output from this scenario was correct except for the times were 3.3 (occasionally 3.6), 4.3, 6.3 (rarely 6.02), and 6.3. We aren't completely sure why this was happening,
but our best guess is that we weren't calling the usleep() function in the correct place and it was sleeping for longer than it should have (i.e. sleeping multiple times during a single loop).

We also noticed in scenario 3 that changing directories into /bin/ and /usr/bin/ seemed to do the same thing. This "sym-link" behavior was mentioned in class today (Tue, Jan 23). 
We felt we should still mention it because when trying to dynamically change the string in brackets when printing out which directory we changed to, we were running into issues.
These were from comparing the string of our expected directory /bin/ to the actual directory /usr/bin/, even though they are the same place.
