#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int main() {
	
	// spacing from previous scenario 
	printf("\n\n\n");

	// read in seed value from seed.txt
	FILE* seedPtr = fopen("seed.txt", "r");
	if (seedPtr == NULL) {
		printf("Could not find seed.txt file\n");
		exit(1);
	}
	int seed;
	fscanf(seedPtr, "%d", &seed);
	printf("Read seed value (converted to integer): %d\n", seed);
	fclose(seedPtr);
	
	// seed srand function
	srand(seed);

	// calculate random lifespan
	int lifespan = rand() % 8 + 5;
	printf("Random Descendant Count: %d\n", lifespan);
	printf("Time to meet the kids/grandkids/great grand kids/...\n");

	// while lifespan > 0, recursively fork to decrement lifespan
	while (lifespan > 0) {
		pid_t pid = fork();
		
		// check for successful fork
		if (pid < 0) {
			printf("fork failed\n");
			exit(1);
		}
		// new child
		if (pid == 0) {
			// child decrements lifespan then loops back to top of while loop to fork again if lifespan > 0
			lifespan--;
			printf("[Child, PID: %d]: I was called with descendant count=%d. I'll have %d descendants.\n", getpid(), lifespan+1, lifespan);
		} 
		// parent
		else {
			// parent waits on child to finish befor exiting
			printf("[Parent, PID: %d]: I am waiting for PID %d to finish.\n", getpid(), pid);
			wait(NULL);
			printf("[Parent, PID: %d]: Child %d finished with status code %d. It's now my turn to exit.\n", getpid(), pid, lifespan-1);
			break;		
		}
	}

	exit(EXIT_SUCCESS);
}
