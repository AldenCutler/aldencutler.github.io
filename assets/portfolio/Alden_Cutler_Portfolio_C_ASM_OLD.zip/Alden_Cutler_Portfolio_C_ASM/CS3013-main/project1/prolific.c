#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int main() {

	// get seed from seed.txt
	FILE* seedPtr = fopen("seed.txt", "r");
	if (seedPtr == NULL) {
		printf("Could not find seed.txt file");
		exit(1);
	}

	int seed;
	fscanf(seedPtr, "%d", &seed);
	printf("Read seed value (converted to integer): %d\n", seed);
	fclose(seedPtr);
	
	// set srand seed to choose random numbers
	srand(seed);


	// rand() % 6 returns a value between 0 and 5,
	// so +8 makes it between 8 and 13
	int numChildren = (rand() % 6) + 8;
	printf("Random Child Count: %d\n", numChildren);

	// generate random number for each child and store in array
	int childRandNums[numChildren];
	for (int i = 0; i < numChildren; i++) {
		childRandNums[i] = rand();
	}


	// for each child
	// int exitCode;
	for (int i = 0; i < numChildren; i++) {
		int rc = fork(); 	// will store child's pid
	
		// if fork fails
		if (rc < 0) {
			printf("fork failed\n");
			exit(1);
		}
		// new child process
		else if (rc == 0) {
			// calculate wait tiem and exit code
			int exitCode = childRandNums[i] % 50 + 1;
			int waitTime = childRandNums[i] % 3 + 1;
			
			// print out values
			pid_t myPid = getpid();
			printf("	[Child, PID: %d]: I am the child and I will wait %d seconds and exit with code %d.\n", myPid, waitTime, exitCode);
			
			// sleep for specified wait time
			sleep(waitTime);

			// exit with specified exit code
			printf("	[Child, PID: %d]: Now exiting...\n", myPid);
			exit(exitCode);
		}
		// parent
		else {
			// wait for child to exit before moving onto next child
			int exitCode;
			printf("[Parent]: I am waiting for PID: %d to finish.\n", rc);		
			waitpid(rc, &exitCode, WCONTINUED);

			// exit code is stored in upper 8 bits of exitCode, so divide by 256 or shift right by 8 to get actual exit code
			exitCode = exitCode >> 8;
			printf("[Parent]: Child %d finished with status code %d. Onward!\n", rc, exitCode);
		}
	}

	// exit with success code
	exit(EXIT_SUCCESS);
}


