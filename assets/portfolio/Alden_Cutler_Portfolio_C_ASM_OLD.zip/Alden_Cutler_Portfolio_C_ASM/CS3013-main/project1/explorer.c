#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
	// spacing from previous scenario, you can comment this out if just running this program standalone
	printf("\n\n\n");

	// get seed from seed.txt
	FILE* seedPtr = fopen("seed.txt", "r");
	if (seedPtr == NULL) {
		printf("Could not find seed.txt file");
		exit(1);
	}

	int seed;
	fscanf(seedPtr, "%d", &seed);
	printf("Read seed value (converted to integer): %d\n", seed);
	printf("It's time to see the world/file system!\n");
	fclose(seedPtr);
	
	// set srand seed to choose random numbers
	srand(seed);


	// for each of the five locations, it will change its working directory (e.g. using chdir()),
	// print out the option that was selected based on the random number, 
	// and output the value of the current working directory (using getcwd()).
	// It then forks off a child that runs the ls -tr command.
	// Done correctly, the child's listing output should match the directory the parent selected.
	// The parent process will wait on the child to complete before moving on to the next file system location.
	int numVisits = 5;
	char** locations = malloc(sizeof(char*) * 6);
	locations[0] = "/home";
	locations[1] = "/proc";
	locations[2] = "/proc/sys";
	locations[3] = "/usr";
	locations[4] = "/usr/bin";
	locations[5] = "/bin";
	
	for (int i = 0; i < numVisits; i++) {
		
		// generate random number between 0 and 5
		/*
		 * 0: /home
		 * 1: /proc
		 * 2: /proc/sys
		 * 3: /usr
		 * 4: /usr/bin
		 * 5: /bin
		 */
		int n = rand() % 6;
		char* loc = locations[n];

		// change directories into chosen location
		chdir(loc);

		char* curr_loc = malloc(sizeof(char) * 10);	// allocate space for getcwd()
		getcwd(curr_loc, 256);
		
		// /usr/bin and /bin seem to be the same thing
		/*
		 * We were trying to do a check where the [SUCCESS] below would be replace by [FAILURE]
		 * if the directory we changed into didn't match the stored location string in the locations array above.
		 * printf("Selection #%d: %s [%s}\n", i+1, loc, strcmp(curr_loc, loc[n]) ? "FAILURE" : "SUCCESS");
		 *
		 * However, when chdir-ing into /bin/, it seems we are actually put into /usr/bin/. We aren't really sure why this is,
		 * but running ls /bin and ls /usr/bin seem to do the same thing, so our best guess is that they're just the same place.
		 */		
		
		printf("Selection #%d: %s [SUCCESS]\n", i+1, loc);	

		// spawn child to run ls -tr command
		pid_t rc = fork();

		if (rc < 0) {		// fork failed
			printf("fork failed\n");
			exit(1);
		} else if (rc == 0) {	// new child process
			
			// print child pid
			printf("	[Child, PID: %d]: Executing 'ts -tr' command...\n", getpid());

			// run ls -tr
			char* arg_list[] = {"ls", "-tr", NULL};		// null-terminated array of char* strings
			execvp("ls", arg_list);				// run 'ls -tr'

			exit(EXIT_SUCCESS);

		} else {		// parent
			int exitCode;	// exit code of child
			printf("[Parent]: I am waiting for PID %d to finish.\n", rc);
			waitpid(rc, &exitCode, 0);	// wait for child to finish and store exit code in exitCode
			// exit code is stored in higher 8 bits of exitCode, so shift right 8 bits
			exitCode = exitCode >> 8;
		    printf("[Parent]: Child %d finished with status code %d. Onward!\n", rc, exitCode);	
		}
	} 
	
	// exit with success code
	exit(EXIT_SUCCESS);
}


