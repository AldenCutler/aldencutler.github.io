export type Player = {
    fName: string;
    lName: string;
    abbr: string;
}