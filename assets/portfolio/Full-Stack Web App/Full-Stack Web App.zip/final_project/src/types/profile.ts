export type UserPass = {
    user: string;
    pass: string;
    type: string;
};